#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "heap.h"

/* Your Heap implementation here */
// Some of these functions are not mentioned in the writeup
// but are useful helper functions that you can use 


void swap(Heap* h, int index1, int index2) {
  Entry* temp = h->elements[index1];
  h->elements[index1] = h->elements[index2];
  h->elements[index2] = temp;
}

void expandCapacity(Heap* h) {
  Entry** expanded = calloc(h->capacity * 2, sizeof(Entry*));
  int i;
  for(i = 0; i < h->size; i += 1) {
    expanded[i] = h->elements[i];
  }
  h->elements = expanded;
  h->capacity*= 2;
}

void bubbleUp(Heap* h, int index) {
  if(index <= 0) { return; }
  int parentIndex = (index - 1) / 2;
  Entry* e = h->elements[index];
  Entry* parent = h->elements[parentIndex];
  if( e->key > parent->key ) {
	  swap(h, index, parentIndex);
	  bubbleUp(h, parentIndex);
  }
}

void add(Heap* h, int k, char* val) {
  Entry* newentry = calloc(1, sizeof(Entry));
  newentry->key = k;
  newentry->value = val;

  if(h->size == h->capacity) { expandCapacity(h); }
  h->elements[h->size] = newentry;
  bubbleUp(h, h->size);
  h->size+=1;
}

void bubbleDown(Heap* h, int index) {
  if(index >= h->capacity ) {return;}
  int leftIndex = 2 * index + 1;
  if(leftIndex >= h->capacity) {return;}
  int smallerChildIndex = leftIndex;
  int rightIndex = 2 * index + 2;
  if(h->elements[rightIndex] != NULL && h->elements[leftIndex] != NULL 
		  && h->elements[rightIndex]->key < h->elements[leftIndex]->key) 
		  {
			  smallerChildIndex = rightIndex;
		  }
  if(h->elements[smallerChildIndex] != NULL && 
	  h->elements[smallerChildIndex]->key < h->elements[index]->key)
	  {
		  swap(h, index, smallerChildIndex);
		  bubbleDown(h, smallerChildIndex);
	  }
}

char* removeMin(Heap* h) {
  if(size(h) == 0) {return NULL;}
  Entry* toRemove = h->elements[0];
  char* toReturn = toRemove->value;
  swap(h, 0, h->size-1);
  free(toRemove);
  bubbleDown(h, 0);
  h->size-=1;
  return toReturn;
}

bool isHeapAt(Heap* h, int index) {

}

void cleanupHeap(Heap* h) {
  int i;
  for(i = 0; i < h->size; i++) {
	  free(h->elements[i]);
  }
  free(h->elements);
  free(h);
}

void printHeap(Heap* h) {
  printHelper(h, 0); 
}

Heap* makeHeap(int capacity) {
  Heap* h = calloc(1, sizeof(Heap));
  Entry** elements = calloc(capacity, sizeof(Entry*));

  h->capacity = capacity;
  h->size = 0;
  h->elements = elements;
  return h;
}

char* peek(Heap* heap) {
  if(size(heap) == 0) {return NULL;}
  return heap->elements[0]->value;;
}

int size(Heap* heap) {
  return heap->size;
}

void printHelper(Heap* h, int pos) {
	if(pos >= size(h)) {return;}
	printf("%d -> %p,", h->elements[pos]->key, h->elements[pos]->value);
	printHelper(h, pos * 2 + 1);
	printHelper(h, pos * 2 + 2);
}
